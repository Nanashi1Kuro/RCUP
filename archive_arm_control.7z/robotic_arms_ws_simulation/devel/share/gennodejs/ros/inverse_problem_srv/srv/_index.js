
"use strict";

let publish_cmd = require('./publish_cmd.js')
let point_cmd = require('./point_cmd.js')

module.exports = {
  publish_cmd: publish_cmd,
  point_cmd: point_cmd,
};
