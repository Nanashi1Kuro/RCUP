#!/usr/bin/env python
import rospy
from sensor_msgs.msg import JointState
import math
from inverse_problem_srv.srv import publish_cmd,publish_cmdResponse

jointPub = rospy.Publisher('/angle_robot/joint_states',JointState,queue_size = 100)

currentState = JointState()
currentState.position = [0,0,0,0,0,0]
maxVelocity = 0.835
kAcc = 0.3
timeRate = 20
countOfJoint = 6

def realize_of_principle(velList,goalPoseMsg,timeOfWay,klAccList,klSlowList):
    global currentState
    newJointState = JointState()
    newJointState.position = list(currentState.position)
    newJointState.name = goalPoseMsg.name
    rate = rospy.Rate(timeRate)
    startTime = rospy.get_time()
    lastTime = startTime
    while((rospy.get_time()-startTime)<timeOfWay*kAcc):
        newTime = rospy.get_time()
        for i in range(len(goalPoseMsg.position)-1):
            newJointState.position[i] += klAccList[i]*(newTime-startTime)*(newTime-lastTime)
        newJointState.header.stamp = rospy.Time.now()
        jointPub.publish(newJointState)
        lastTime = rospy.get_time()
        rate.sleep()
        
    rate = rospy.Rate(timeRate)
    startTime = lastTime
    lastTime = startTime
    while((rospy.get_time()-startTime)<timeOfWay*(1-2*kAcc)):
        newTime = rospy.get_time()
        for i in range(len(goalPoseMsg.position)-1):
            newJointState.position[i] += velList[i]*(newTime-lastTime)
        newJointState.header.stamp = rospy.Time.now()
        jointPub.publish(newJointState)
        lastTime = rospy.get_time()
        rate.sleep()

    rate = rospy.Rate(timeRate)
    startTime = lastTime
    lastTime = startTime
    while((rospy.get_time()-startTime)<timeOfWay*kAcc):
        newTime = rospy.get_time()
        for i in range(len(goalPoseMsg.position)-1):
            newJointState.position[i] += (velList[i]-klSlowList[i]*(newTime-startTime))*(newTime-lastTime)
        newJointState.header.stamp = rospy.Time.now()
        jointPub.publish(newJointState)
        lastTime = rospy.get_time()
        rate.sleep()
    goalPoseMsg.header.stamp = rospy.Time.now()
    jointPub.publish(goalPoseMsg)
    currentState.position = goalPoseMsg.position

def way_compute(posList):
    global currentState
    wayList = []
    for i in range(len(posList)-1):
        wayList.append(posList[i]-currentState.position[i])
    return wayList

def max_way(wayList):
    maxWay = wayList[len(wayList)-1]
    for i in range(len(wayList)-1):
        if (math.fabs(wayList[i])>math.fabs(maxWay)):
            maxWay = wayList[i]
        else:
            continue
    return maxWay

def parse_msg(msg):
    jointState = JointState()
    msgList = msg.jointState.split()
    jointState.name = msgList[0:countOfJoint]
    jointState.position = msgList[countOfJoint:]
    jointState.position = [float(el) for el in jointState.position] 
    return jointState

def move_of_trapeze_principle(msg):
    msg = parse_msg(msg)
    currentState.position[countOfJoint-1] = msg.position[countOfJoint-1]
    velList = []
    klAccList = []
    klSlowList = []
    wayList = way_compute(msg.position)
    maxWay = max_way(wayList)
    kVel = (1-kAcc)
    timeOfWay = math.fabs(maxWay/(maxVelocity*kVel))
    if (timeOfWay == 0):
        rate = rospy.Rate(10)
        i = 0
        while (i<5): #MEGA KOSTYLLLLLLLLLLLLLLLLLLLLLLLLL'
            msg.header.stamp = rospy.Time.now()
            jointPub.publish(msg)
            i+=1
            rate.sleep()
        return publish_cmdResponse(True)
    for i in range(len(msg.position)-1):
        velList.append(wayList[i]/(timeOfWay*kVel))
    for i in range(len(velList)):
        klAccList.append(velList[i]/timeOfWay/kAcc)
        klSlowList.append(velList[i]/timeOfWay/kAcc)
    realize_of_principle(velList,msg,timeOfWay,klAccList,klSlowList)
    return publish_cmdResponse(True)
     

if __name__=='__main__':
    rospy.init_node('angle_convert_and_publish_state')
    rospy.loginfo('Start_convert_and_publish_state_node')
    rospy.Service('/angle_robot/cmd_joint_state_in_manip_coord', publish_cmd, move_of_trapeze_principle)
    rospy.spin()
