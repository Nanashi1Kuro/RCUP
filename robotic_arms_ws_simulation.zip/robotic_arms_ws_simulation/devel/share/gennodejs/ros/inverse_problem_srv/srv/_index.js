
"use strict";

let point_cmd = require('./point_cmd.js')
let publish_cmd = require('./publish_cmd.js')

module.exports = {
  point_cmd: point_cmd,
  publish_cmd: publish_cmd,
};
